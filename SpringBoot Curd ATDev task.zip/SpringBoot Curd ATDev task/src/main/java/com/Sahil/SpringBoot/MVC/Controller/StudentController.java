package com.Sahil.SpringBoot.MVC.Controller;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Sahil.SpringBoot.MVC.Model.Student;

import org.hibernate.Session;

@Controller
public class StudentController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("myHome")
	private String home() {
		return "home";
	}
	
	@RequestMapping("createAccount")
	private String save() {
		return "save";
	}
	

	@PostMapping("/save")
	private String saveDataBase(Student student) {
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.save(student);
		t.commit();
		return "viewstudent";
	}
	
	@RequestMapping("updatepage")
	private String updatepage() {
		return "update";
	}
	
	@RequestMapping("/update")
	private String updateDataBase(Student student) {
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.update(student);
		t.commit();
		return "viewstudent";
	} 
	
	@RequestMapping("deletepage")
	private String deletepage() {
		return "delete";
	}
	
	@RequestMapping("/delete")
	private String deleteDataBase(Student student) {
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Student ss=s.get(Student.class, student.getId());
		s.delete(ss);
		t.commit();
		return "viewstudent";
	}
	 
	@RequestMapping("viewtable")
	public String name() {
		return "viewstudent";
	}

}
 